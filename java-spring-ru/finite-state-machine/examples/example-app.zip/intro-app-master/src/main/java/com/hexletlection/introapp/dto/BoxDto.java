package com.hexletlection.introapp.dto;

public class BoxDto {
    private String number;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
