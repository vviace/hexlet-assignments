package com.hexletlection.introapp.service;

import com.hexletlection.introapp.dto.CarDto;
import com.hexletlection.introapp.model.Car;
import com.hexletlection.introapp.model.Document;

import java.util.List;

public interface DocumentService {
    void save(Document document);
}
