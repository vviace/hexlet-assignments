package com.hexletlection.introapp.service;

import com.hexletlection.introapp.model.Box;

public class BoxServiceImpl implements BoxService {
    @Override
    public void save(Box box) {

    }
}
