package com.hexletlection.introapp.service;

import com.hexletlection.introapp.model.Document;

public class DocumentServiceImpl implements DocumentService{
    @Override
    public void save(Document document) {

    }
}
