package com.hexletlection.introapp.model;

public enum Status {
    CAR_IN_PROD,
    CAR_PROD_COMPLETED,
    CAR_DELIVERED,
    FINISH,
    START;
}
