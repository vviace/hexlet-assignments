package com.hexletlection.introapp.service;

import com.hexletlection.introapp.dto.CarDto;
import com.hexletlection.introapp.model.Box;
import com.hexletlection.introapp.model.Car;

import java.util.List;

public interface BoxService {
    void save(Box box);
}
